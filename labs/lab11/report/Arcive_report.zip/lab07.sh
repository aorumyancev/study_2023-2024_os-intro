#!/bin/bash
HELL=Hello
function hello {

hello
echo $HELLO
    local HELLO= World
    echo $HELLO
}













